@@ -1,2 +1,2 @@
# CryptLink
Crypt Link is a web application providing secure and encrypted messaging and file storage. Can be used in a personal setting but is suited for secure project development. Aims to provide a workspace for developers to have protected communication and file management/storage.

kj here
Chi here
Harsh here
Zakir here
comment here    
Mahmood here