package com.cryptLink.CryptLinkBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CryptLinkBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
